<?php
header( $_SERVER['SERVER_PROTOCOL'] . ' 404 Not Found' );
header( 'Status: 404 Not Found' );
